---
title: Abyssinica SIL - Design
fontversion: 2.300
---

Abyssinica SIL is based on Ethiopic calligraphic traditions. 

One font from this typeface family is included in the *Abyssinica SIL* release (no bold or italic version available or planned):

* Abyssinica SIL Regular


## Type Samples

Type samples showing some of the inventory of glyphs can be found here: 
[Abyssinica SIL Type Sample](sample.md).

A sample from one page is shown below. 

![Abyssinica SIL Sample - Ethiopic syllables](../assets/images/AbyssinicaTypeSamplev2.png){.fullsize}
<!-- PRODUCT SITE IMAGE SRC https://software.sil.org/abyssinica/wp-content/uploads/sites/26/2019/09/AbyssinicaTypeSamplev2.png -->
<figcaption>Abyssinica SIL Sample - Ethiopic syllables</figcaption>

