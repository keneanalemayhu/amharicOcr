## [LICENSE-AnbassaDesign.txt](./AnbassaDesigner/LICENSE-AnbassaDesign.txt)
  * Adwa-Bold.ttf
  * Adwa-Regular.ttf
  * AdwaSansSerif-Bold.ttf
  * AdwaSansSerif-Regular.ttf
  * Entoto.ttf
  * Godana-Regular.ttf
  * Meaza.ttf
  * Neteru.ttf
  * Shiromeda-Bold.ttf
  * Shiromeda-Regular.ttf
  * Shiromeda-SemiBold.ttf
  * ShiromedaSerif-Bold.ttf
  * ShiromedaSerif-Regular.ttf
  * ShiromedaSerif-SemiBold.ttf
  * Tayitu.ttf

## [LICENSE-GeezFonts.txt](./GeezFonts/LICENSE-GeezFonts.txt)
  * Geez Pixels 2.ttf
  * GeezDigital_V1.ttf

## [LICENSE-HAHUU.txt](./HaaHu/LICENSE-HAHUU.txt)
* ETH_B_GOFA.ttf

## [LICENSE-HalwoteHareg.txt](HalwoteHareg/LICENSE-HalwoteHareg.txt)
* HH Lemd Mono-Regular.otf

## [LICENSE-MetaAppz.txt](./MetaAppz/LICENSE-MetaAppz.txt)
* Chiret-Regular.ttf
* Seat.ttf
* Tera.ttf

## [LICENSE-Qedron.txt](./Qedron/LICENSE-Qedron.txt)
* kiros.ttf

## [LICENSE-RoadToEthiopia.txt](./RoadToEthiopia/LICENSE-RoadToEthiopia.txt)
* Addis.ttf
* Dire_Dawa.ttf

## [LICENSE-TypeHabesha.txt](./TypeHabesha/LICENSE-TypeHabesha.txt)
* Habesha Serif Distort Italic.ttf
* Habesha Serif Distort.ttf
* Zibriqriq - ዝብርቅርቅ.ttf

## [LICENSE-Wazéma.txt](./Wazéma/LICENSE-Wazéma.txt)
* A0AddisAbebaUnicode_20030827.ttf
* A0DestaUnicode_20030827.ttf
* A0TesfaUnicode_20030720.ttf

## [LICENSE-YonathanSeyoum.txt](./YonathanSeyoum/LICENSE-YonathanSeyoum.txt)
* HABESHAPIXELS-Bold.ttf
* HABESHAPIXELS.ttf
* Habesha STENCIL.ttf
* Habesha_Blocks.ttf
* Habesha_Blocks_BLACK.ttf
* Habesha_Blocks_OUTLINES.ttf
* ahabeshastypewriter-regular.ttf

## [LICENSE-TITUS.txt](./TITUS/LICENSE-TITUS.txt)
  * TITUS Cyberbit Basic Regular.ttf
