The fonts provided within this folder are free to use for both personal
and commercial projects and can be redistributed with the consent
of the creators.  Please review the individual LICENSE files in the
subfolders for additional details.
